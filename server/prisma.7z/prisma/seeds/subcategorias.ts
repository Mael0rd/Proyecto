export const subcategorias = [
  //1
  {
    descripcion: "Moto Cross",
  },
  {
    descripcion: "Trail",
  },
  {
    descripcion: "Doble Proposito",
  },
  {
    descripcion: "Pistera",
  },
  {
    descripcion: "Scooter",
  },
  {
    descripcion: "Bicicleta",
  },
];
