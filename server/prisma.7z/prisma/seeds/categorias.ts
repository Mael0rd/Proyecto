export const categorias = [
  { descripcion: "Motos eléctricas" },
  { descripcion: "Motos de gasolina" },
  { descripcion: "Bicimotos" },
];
