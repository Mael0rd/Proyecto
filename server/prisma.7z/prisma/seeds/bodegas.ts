export const bodegas = [
    //bodega 1
    { nombre: "Bodega el Coyol",
      dimensiones:"1000 m2",
        capacidad:"10000",
        seguro:true,
        
         },
    //bodega 2
    { nombre: "Bodega La Uruca",
      dimensiones:"2000 m2",
        capacidad:"30000",
        seguro:true,
        
         },
    //bodega 3
    { nombre: "Bodega Santa Ana",
      dimensiones:"500 m2",
        capacidad:"2000",
        seguro:true,
        
         },
  ];