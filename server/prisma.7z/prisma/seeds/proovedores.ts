export const proovedores = [
  //proovedor 1
  {
    nombre: "Red Motors",
    correo: "redmotors@gmail.com",
    numeroTelefonico: "800-red",
    direccionExacta: "Santa Ana, 200 metros oeste de la estacion de bomberos",
  },
  //proovedor 2
  {
    nombre: "Susuky",
    correo: "adminsusuky@gmail.com",
    numeroTelefonico: "2438-5298",
    direccionExacta: "La uruca, 200 metros oeste de la estacion de bomberos",
  },
];
